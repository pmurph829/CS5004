/** Enum that holds the different types of node. */
public enum NodeType {
  EMPTY,
  PUNCTUATION,
  WORD
}
