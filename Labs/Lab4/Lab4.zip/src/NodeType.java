/** Enum that stores the possible types of node. */
public enum NodeType {
  WORD,
  PUNCTUATION
}
