package cs5004.tictactoe;

/** Enum that defines the player. */
public enum Player {
  X,
  O
}
