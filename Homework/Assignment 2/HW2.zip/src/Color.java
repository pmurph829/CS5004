/** Enum that defines the possible colors of ChessPiece instances. */
public enum Color {
  BLACK,
  WHITE
}
